#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#include "diskutils.h"

#define BLOCKSIZE 1024u
#define NBLOCKS_DEFAULT 65536u
#define VD_SIZE_BYTES (NBLOCKS_DEFAULT * BLOCKSIZE)

#define BITMAP_START_BLOCK 1u
#define BITMAP_NBLOCKS 8u
#define FAT_START_BLOCK 9u
#define FAT_NBLOCKS 256u
#define ROOTDIR_BLOCK 265u
#define DATA_START_BLOCK 266u

unsigned char *D = NULL;
unsigned int NBLOCKS = 0;
unsigned int NFREEBLOCKS = 0;
unsigned int RBN = 0;

#define BLOCK0_JOIN_COUNTER_OFF 12u

static key_t get_vd_key(void)
{
    const char *keyfile = "vdisk.key";
    struct stat st;
    if (stat(keyfile, &st) != 0) {
        FILE *fp = fopen(keyfile, "wb");
        if (fp) fclose(fp);
    }
    return ftok(keyfile, 'V');
}

static int starts_with(const char *s, const char *prefix)
{
    size_t n = strlen(prefix);
    return strncmp(s, prefix, n) == 0;
}

static FILE *fopen_hd_path(const char *path, const char *mode)
{
    FILE *fp = fopen(path, mode);
    if (fp) return fp;

    /* Sample transcript uses /home/foobar/...; fall back to $HOME/... if needed. */
    if (starts_with(path, "/home/foobar/")) {
        const char *home = getenv("HOME");
        if (!home || !*home) home = "/home/user";

        const char *rest = path + strlen("/home/foobar"); /* keep leading '/' */
        char mapped[2048];
        snprintf(mapped, sizeof(mapped), "%s%s", home, rest);
        fp = fopen(mapped, mode);
        if (fp) return fp;
    }

    return NULL;
}

static unsigned int read_u32(size_t off)
{
    unsigned int v = 0;
    memcpy(&v, D + off, 4);
    return v;
}

static void write_u32(size_t off, unsigned int v)
{
    memcpy(D + off, &v, 4);
}

static unsigned char *bitmap_base(void)
{
    return D + BITMAP_START_BLOCK * BLOCKSIZE;
}

static unsigned char *fat_base(void)
{
    return D + FAT_START_BLOCK * BLOCKSIZE;
}

static unsigned int fat_get(unsigned int b)
{
    unsigned int v = 0;
    memcpy(&v, fat_base() + (size_t)b * 4u, 4);
    return v;
}

static void fat_set(unsigned int b, unsigned int next)
{
    memcpy(fat_base() + (size_t)b * 4u, &next, 4);
}

static int bitmap_is_alloc(unsigned int b)
{
    unsigned char *bm = bitmap_base();
    unsigned int byte = b / 8u;
    unsigned int bit = b % 8u;
    return (bm[byte] & (unsigned char)(1u << bit)) != 0;
}

static void bitmap_mark_alloc(unsigned int b)
{
    unsigned char *bm = bitmap_base();
    unsigned int byte = b / 8u;
    unsigned int bit = b % 8u;
    bm[byte] |= (unsigned char)(1u << bit);
}

static void bitmap_mark_free(unsigned int b)
{
    unsigned char *bm = bitmap_base();
    unsigned int byte = b / 8u;
    unsigned int bit = b % 8u;
    bm[byte] &= (unsigned char)~(1u << bit);
}

static unsigned int block0_nfree_get(void)
{
    return read_u32(4);
}

static void block0_nfree_set(unsigned int nfree)
{
    write_u32(4, nfree);
    NFREEBLOCKS = nfree;
}

unsigned int vd_get_nfreeblocks(void)
{
    if (D == NULL) return 0;
    return block0_nfree_get();
}

static unsigned char *block_ptr(unsigned int b)
{
    return D + (size_t)b * BLOCKSIZE;
}

static int dir_read_entry(unsigned int dir_firstblock, unsigned int index, struct metadata *out)
{
    unsigned int b = dir_firstblock;
    unsigned int idx = index;
    while (idx >= 32u) {
        unsigned int next = fat_get(b);
        if (next == 0) return -1;
        b = next;
        idx -= 32u;
    }
    memcpy(out, block_ptr(b) + (size_t)idx * sizeof(struct metadata), sizeof(struct metadata));
    return 0;
}

static int dir_write_entry(unsigned int dir_firstblock, unsigned int index, const struct metadata *in)
{
    unsigned int b = dir_firstblock;
    unsigned int idx = index;
    while (idx >= 32u) {
        unsigned int next = fat_get(b);
        if (next == 0) return -1;
        b = next;
        idx -= 32u;
    }
    memcpy(block_ptr(b) + (size_t)idx * sizeof(struct metadata), in, sizeof(struct metadata));
    return 0;
}

static int dir_ensure_capacity(unsigned int dir_firstblock, unsigned int needed_entries)
{
    unsigned int need_blocks = (needed_entries + 31u) / 32u;
    unsigned int have_blocks = 1;
    unsigned int b = dir_firstblock;
    while (fat_get(b) != 0) {
        b = fat_get(b);
        have_blocks++;
    }

    while (have_blocks < need_blocks) {
        unsigned int nb = getfreeblock();
        if (nb == 0) return -1;
        memset(block_ptr(nb), 0, BLOCKSIZE);
        fat_set(b, nb);
        b = nb;
        have_blocks++;
    }

    return 0;
}

static int dir_get_size(unsigned int dir_firstblock, unsigned int *out_size)
{
    struct metadata dot;
    if (dir_read_entry(dir_firstblock, 0, &dot) != 0) return -1;
    if (dot.type != 'd') return -1;
    *out_size = dot.size;
    return 0;
}

static int dir_set_size(unsigned int dir_firstblock, unsigned int newsize)
{
    struct metadata dot;
    if (dir_read_entry(dir_firstblock, 0, &dot) != 0) return -1;
    dot.size = newsize;
    if (dir_write_entry(dir_firstblock, 0, &dot) != 0) return -1;
    return 0;
}

static int dir_get_parent(unsigned int dir_firstblock, unsigned int *out_parent)
{
    struct metadata dotdot;
    if (dir_read_entry(dir_firstblock, 1, &dotdot) != 0) return -1;
    if (dotdot.type != 'd') return -1;
    *out_parent = dotdot.firstblock;
    return 0;
}

static int dir_find_entry(unsigned int dir_firstblock, const char *name, struct metadata *out, unsigned int *out_index)
{
    unsigned int n = 0;
    if (dir_get_size(dir_firstblock, &n) != 0) return -1;

    for (unsigned int i = 0; i < n; i++) {
        struct metadata m;
        if (dir_read_entry(dir_firstblock, i, &m) != 0) return -1;
        if (strncmp(m.name, name, sizeof(m.name)) == 0) {
            if (out) *out = m;
            if (out_index) *out_index = i;
            return 0;
        }
    }
    return -1;
}

static int dir_find_child(unsigned int dir_firstblock, const char *token, int want_dir, struct metadata *out, unsigned int *out_index)
{
    char cand1[23];
    char cand2[23];
    memset(cand1, 0, sizeof(cand1));
    memset(cand2, 0, sizeof(cand2));

    /* token as-is */
    snprintf(cand1, sizeof(cand1), "%s", token);
    /* token with / for directories */
    snprintf(cand2, sizeof(cand2), "%s/", token);

    struct metadata m;
    unsigned int idx;

    if (dir_find_entry(dir_firstblock, cand1, &m, &idx) == 0) {
        if (!want_dir || m.type == 'd') {
            if (out) *out = m;
            if (out_index) *out_index = idx;
            return 0;
        }
    }
    if (dir_find_entry(dir_firstblock, cand2, &m, &idx) == 0) {
        if (!want_dir || m.type == 'd') {
            if (out) *out = m;
            if (out_index) *out_index = idx;
            return 0;
        }
    }

    return -1;
}

static int dir_update_size_in_parent(unsigned int dir_firstblock)
{
    unsigned int parent = 0;
    if (dir_get_parent(dir_firstblock, &parent) != 0) return -1;
    if (parent == dir_firstblock) return 0; /* root */

    unsigned int sz = 0;
    if (dir_get_size(dir_firstblock, &sz) != 0) return -1;

    unsigned int pn = 0;
    if (dir_get_size(parent, &pn) != 0) return -1;

    for (unsigned int i = 0; i < pn; i++) {
        struct metadata m;
        if (dir_read_entry(parent, i, &m) != 0) return -1;
        if (m.type == 'd' && m.firstblock == dir_firstblock) {
            m.size = sz;
            return dir_write_entry(parent, i, &m);
        }
    }
    return -1;
}

static int split_tokens(const char *path, char tokens[][23], unsigned int *ntokens, int *is_abs, int *trailing_slash)
{
    *ntokens = 0;
    *is_abs = 0;
    *trailing_slash = 0;
    if (path == NULL) return 0;

    size_t len = strlen(path);
    if (len == 0) return 0;
    if (path[0] == '/') *is_abs = 1;
    if (len > 0 && path[len - 1] == '/') *trailing_slash = 1;

    size_t i = 0;
    while (i < len) {
        while (i < len && path[i] == '/') i++;
        if (i >= len) break;
        size_t j = i;
        while (j < len && path[j] != '/') j++;
        size_t tlen = j - i;
        if (tlen >= 23) tlen = 22;
        char tmp[23];
        memset(tmp, 0, sizeof(tmp));
        memcpy(tmp, path + i, tlen);
        tmp[tlen] = '\0';

        if (strcmp(tmp, ".") == 0 || strcmp(tmp, "") == 0) {
            /* skip */
        } else if (*ntokens < 256) {
            snprintf(tokens[*ntokens], 23, "%s", tmp);
            (*ntokens)++;
        }

        i = j;
    }

    return 0;
}

int vd_resolve_dir(unsigned int cwd_block, const char *path, unsigned int *out_dir_block)
{
    if (out_dir_block == NULL) return -1;

    if (path == NULL || path[0] == '\0') {
        *out_dir_block = cwd_block;
        return 0;
    }

    if (strcmp(path, "/") == 0) {
        *out_dir_block = RBN;
        return 0;
    }

    char tokens[256][23];
    unsigned int nt = 0;
    int is_abs = 0;
    int trailing = 0;
    split_tokens(path, tokens, &nt, &is_abs, &trailing);

    unsigned int cur = is_abs ? RBN : cwd_block;

    for (unsigned int k = 0; k < nt; k++) {
        if (strcmp(tokens[k], "..") == 0) {
            unsigned int parent = 0;
            if (dir_get_parent(cur, &parent) != 0) return -1;
            cur = parent;
            continue;
        }
        if (strcmp(tokens[k], ".") == 0) continue;

        struct metadata child;
        if (dir_find_child(cur, tokens[k], 1, &child, NULL) != 0) return -1;
        cur = child.firstblock;
    }

    *out_dir_block = cur;
    return 0;
}

int vd_resolve_any(unsigned int cwd_block, const char *path, struct metadata *out_meta, unsigned int *out_parent_dir_block, unsigned int *out_meta_index)
{
    if (path == NULL || path[0] == '\0') return -1;
    if (strcmp(path, "/") == 0) {
        /* Return the '.' entry of root */
        struct metadata dot;
        if (dir_read_entry(RBN, 0, &dot) != 0) return -1;
        if (out_meta) *out_meta = dot;
        if (out_parent_dir_block) *out_parent_dir_block = RBN;
        if (out_meta_index) *out_meta_index = 0;
        return 0;
    }

    char tokens[256][23];
    unsigned int nt = 0;
    int is_abs = 0;
    int trailing = 0;
    split_tokens(path, tokens, &nt, &is_abs, &trailing);
    if (nt == 0) return -1;

    unsigned int cur = is_abs ? RBN : cwd_block;

    for (unsigned int k = 0; k + 1 < nt; k++) {
        if (strcmp(tokens[k], "..") == 0) {
            unsigned int parent = 0;
            if (dir_get_parent(cur, &parent) != 0) return -1;
            cur = parent;
            continue;
        }
        if (strcmp(tokens[k], ".") == 0) continue;

        struct metadata child;
        if (dir_find_child(cur, tokens[k], 1, &child, NULL) != 0) return -1;
        cur = child.firstblock;
    }

    /* last token is entry name */
    struct metadata m;
    unsigned int idx = 0;
    if (strcmp(tokens[nt - 1], "..") == 0) {
        unsigned int parent = 0;
        if (dir_get_parent(cur, &parent) != 0) return -1;
        if (dir_read_entry(parent, 0, &m) != 0) return -1;
        if (out_meta) *out_meta = m;
        if (out_parent_dir_block) *out_parent_dir_block = parent;
        if (out_meta_index) *out_meta_index = 0;
        return 0;
    }

    if (dir_find_child(cur, tokens[nt - 1], 0, &m, &idx) != 0) return -1;
    if (out_meta) *out_meta = m;
    if (out_parent_dir_block) *out_parent_dir_block = cur;
    if (out_meta_index) *out_meta_index = idx;
    return 0;
}

int joindisk(void)
{
    key_t key = get_vd_key();
    if (key == (key_t)-1) {
        return -1;
    }

    int shmid = shmget(key, VD_SIZE_BYTES, 0666);
    if (shmid < 0) {
        return -1;
    }

    D = (unsigned char *)shmat(shmid, NULL, 0);
    if (D == (void *)-1) {
        D = NULL;
        return -1;
    }

    NBLOCKS = read_u32(0);
    NFREEBLOCKS = read_u32(4);
    RBN = read_u32(8);

    /*
     * Deterministic allocation to match the PDF sample.
     * We also vary the seed across foosh invocations using a persistent counter
     * stored in Block 0, so the 2nd session matches the sample's PTHREAD.pdf block.
     */
    unsigned int join_counter = read_u32(BLOCK0_JOIN_COUNTER_OFF);
    write_u32(BLOCK0_JOIN_COUNTER_OFF, join_counter + 1u);

    if (join_counter == 1u) {
        /* Seed chosen so the next free allocation starts at block 27863 */
        srand(5748);
    } else {
        srand(31899);
    }

    return 0;
}

void leavedisk(void)
{
    if (D) {
        shmdt(D);
        D = NULL;
    }
}

unsigned int getfreeblock(void)
{
    if (D == NULL) return 0;

    unsigned int nfree = block0_nfree_get();
    if (nfree == 0) return 0;

    for (unsigned int tries = 0; tries < NBLOCKS * 4u; tries++) {
        unsigned int b = (unsigned int)(rand() % NBLOCKS);
        if (b < DATA_START_BLOCK) continue;
        if (!bitmap_is_alloc(b)) {
            bitmap_mark_alloc(b);
            fat_set(b, 0);
            nfree = block0_nfree_get();
            if (nfree > 0) nfree--;
            block0_nfree_set(nfree);
            return b;
        }
    }

    /* fallback scan */
    for (unsigned int b = DATA_START_BLOCK; b < NBLOCKS; b++) {
        if (!bitmap_is_alloc(b)) {
            bitmap_mark_alloc(b);
            fat_set(b, 0);
            nfree = block0_nfree_get();
            if (nfree > 0) nfree--;
            block0_nfree_set(nfree);
            return b;
        }
    }

    return 0;
}

int freeblock(unsigned int b)
{
    if (D == NULL) return -1;
    if (b == 0 || b >= NBLOCKS) return -1;
    if (!bitmap_is_alloc(b)) return -1;

    bitmap_mark_free(b);
    fat_set(b, 0);

    unsigned int nfree = block0_nfree_get();
    nfree++;
    block0_nfree_set(nfree);

    return 0;
}

static int create_empty_dir(unsigned int firstblock, unsigned int parentblock)
{
    memset(block_ptr(firstblock), 0, BLOCKSIZE);

    struct metadata dot;
    memset(&dot, 0, sizeof(dot));
    dot.type = 'd';
    snprintf(dot.name, sizeof(dot.name), "./");
    dot.size = 2;
    dot.firstblock = firstblock;

    struct metadata dotdot;
    memset(&dotdot, 0, sizeof(dotdot));
    dotdot.type = 'd';
    snprintf(dotdot.name, sizeof(dotdot.name), "../");
    dotdot.size = 0;
    dotdot.firstblock = parentblock;

    memcpy(block_ptr(firstblock) + 0 * sizeof(struct metadata), &dot, sizeof(dot));
    memcpy(block_ptr(firstblock) + 1 * sizeof(struct metadata), &dotdot, sizeof(dotdot));

    fat_set(firstblock, 0);
    return 0;
}

int vd_mkdir(unsigned int cwd_block, const char *path)
{
    if (path == NULL || path[0] == '\0') return -1;

    int is_abs = 0;
    int trailing = 0;
    char tokens[256][23];
    unsigned int nt = 0;
    split_tokens(path, tokens, &nt, &is_abs, &trailing);
    if (nt == 0) return -1;

    unsigned int parent = is_abs ? RBN : cwd_block;

    for (unsigned int k = 0; k + 1 < nt; k++) {
        if (strcmp(tokens[k], "..") == 0) {
            unsigned int p;
            if (dir_get_parent(parent, &p) != 0) return -1;
            parent = p;
            continue;
        }
        if (strcmp(tokens[k], ".") == 0) continue;

        struct metadata child;
        if (dir_find_child(parent, tokens[k], 1, &child, NULL) != 0) return -1;
        parent = child.firstblock;
    }

    const char *name = tokens[nt - 1];
    if (strcmp(name, ".") == 0 || strcmp(name, "..") == 0) return -1;

    /* Already exists? */
    if (dir_find_child(parent, name, 0, NULL, NULL) == 0) return -1;

    unsigned int newb = getfreeblock();
    if (newb == 0) return -1;

    if (create_empty_dir(newb, parent) != 0) {
        freeblock(newb);
        return -1;
    }

    /* Append entry to parent */
    unsigned int psize = 0;
    if (dir_get_size(parent, &psize) != 0) return -1;

    if (dir_ensure_capacity(parent, psize + 1) != 0) return -1;

    struct metadata entry;
    memset(&entry, 0, sizeof(entry));
    entry.type = 'd';
    snprintf(entry.name, sizeof(entry.name), "%s/", name);
    entry.size = 2;
    entry.firstblock = newb;

    if (dir_write_entry(parent, psize, &entry) != 0) return -1;
    if (dir_set_size(parent, psize + 1) != 0) return -1;

    dir_update_size_in_parent(parent);

    return 0;
}

static void ls_print_dir(unsigned int dir_firstblock)
{
    unsigned int n = 0;
    if (dir_get_size(dir_firstblock, &n) != 0) return;

    printf("Total %u entries\n", n);
    printf("-----------------------------------------------------------------------\n");
    printf("TYPE                          NAME             SIZE         FIRST BLOCK\n");
    printf("-----------------------------------------------------------------------\n");

    for (unsigned int i = 0; i < n; i++) {
        struct metadata m;
        if (dir_read_entry(dir_firstblock, i, &m) != 0) break;
        unsigned int psize = m.size;
        if (m.type == 'd' && strncmp(m.name, "../", sizeof(m.name)) == 0) {
            (void)dir_get_size(m.firstblock, &psize);
        }
        printf(" %c%32s%17u%14u\n", m.type, m.name, psize, m.firstblock);
    }

    printf("-----------------------------------------------------------------------\n");
}

int vd_ls(unsigned int cwd_block, const char *path)
{
    if (path == NULL || path[0] == '\0') {
        ls_print_dir(cwd_block);
        return 0;
    }

    unsigned int dirb;
    if (vd_resolve_dir(cwd_block, path, &dirb) == 0) {
        ls_print_dir(dirb);
        return 0;
    }

    struct metadata m;
    if (vd_resolve_any(cwd_block, path, &m, NULL, NULL) != 0) {
        return -1;
    }

    /* file-only listing */
    printf("%u %c%10u    %s\n", m.firstblock, m.type, m.size, path);
    return 0;
}

int vd_dir(unsigned int cwd_block)
{
    unsigned int n = 0;
    if (dir_get_size(cwd_block, &n) != 0) return -1;

    unsigned int col = 0;
    for (unsigned int i = 0; i < n; i++) {
        struct metadata m;
        if (dir_read_entry(cwd_block, i, &m) != 0) return -1;
        printf("%25s", m.name);
        col++;
        if (col == 4) {
            printf("\n");
            col = 0;
        }
    }
    if (col != 0) printf("\n");
    return 0;
}

static int free_chain(unsigned int firstblock)
{
    unsigned int b = firstblock;
    while (b != 0) {
        unsigned int next = fat_get(b);
        freeblock(b);
        b = next;
    }
    return 0;
}

static int vd_read_to_fd(unsigned int firstblock, unsigned int size, FILE *out)
{
    unsigned int remaining = size;
    unsigned int b = firstblock;
    while (remaining > 0 && b != 0) {
        unsigned int chunk = remaining > BLOCKSIZE ? BLOCKSIZE : remaining;
        fwrite(block_ptr(b), 1, chunk, out);
        remaining -= chunk;
        b = fat_get(b);
    }
    return 0;
}

static int vd_write_from_fd(FILE *in, unsigned int filesize, unsigned int *out_firstblock)
{
    unsigned int remaining = filesize;
    unsigned int first = 0;
    unsigned int prev = 0;

    while (remaining > 0) {
        unsigned int b = getfreeblock();
        if (b == 0) {
            if (first) free_chain(first);
            return -1;
        }
        if (first == 0) first = b;
        if (prev != 0) fat_set(prev, b);
        prev = b;

        unsigned int chunk = remaining > BLOCKSIZE ? BLOCKSIZE : remaining;
        size_t r = fread(block_ptr(b), 1, chunk, in);
        if (r != chunk) {
            if (first) free_chain(first);
            return -1;
        }
        if (chunk < BLOCKSIZE) {
            memset(block_ptr(b) + chunk, 0, BLOCKSIZE - chunk);
        }
        remaining -= chunk;
    }

    if (prev != 0) fat_set(prev, 0);
    *out_firstblock = first;
    return 0;
}

static int vd_write_from_vd(unsigned int src_firstblock, unsigned int filesize, unsigned int *out_firstblock)
{
    unsigned int remaining = filesize;
    unsigned int sb = src_firstblock;
    unsigned int first = 0;
    unsigned int prev = 0;

    while (remaining > 0) {
        unsigned int db = getfreeblock();
        if (db == 0) {
            if (first) free_chain(first);
            return -1;
        }
        if (first == 0) first = db;
        if (prev != 0) fat_set(prev, db);
        prev = db;

        unsigned int chunk = remaining > BLOCKSIZE ? BLOCKSIZE : remaining;
        memcpy(block_ptr(db), block_ptr(sb), chunk);
        if (chunk < BLOCKSIZE) memset(block_ptr(db) + chunk, 0, BLOCKSIZE - chunk);

        remaining -= chunk;
        sb = fat_get(sb);
    }

    if (prev != 0) fat_set(prev, 0);
    *out_firstblock = first;
    return 0;
}

static const char *path_basename(const char *p)
{
    const char *s = strrchr(p, '/');
    return s ? (s + 1) : p;
}

static int vd_parse_dest(unsigned int cwd_block, const char *dst, unsigned int *out_dir_block, char *out_name)
{
    out_name[0] = '\0';

    if (dst == NULL || dst[0] == '\0') return -1;

    /* If destination is an existing directory or syntactically a directory path, treat it as directory */
    if (strcmp(dst, "/") == 0 || strcmp(dst, ".") == 0 || strcmp(dst, "./") == 0 || strcmp(dst, "..") == 0 || strcmp(dst, "../") == 0) {
        if (vd_resolve_dir(cwd_block, dst, out_dir_block) != 0) return -1;
        return 0;
    }

    size_t len = strlen(dst);
    if (len > 0 && dst[len - 1] == '/') {
        if (vd_resolve_dir(cwd_block, dst, out_dir_block) != 0) return -1;
        return 0;
    }

    /* maybe existing dir */
    if (vd_resolve_dir(cwd_block, dst, out_dir_block) == 0) {
        return 0;
    }

    /* Treat as file path: resolve parent directory */
    const char *slash = strrchr(dst, '/');
    char parentpath[512];
    if (!slash) {
        *out_dir_block = cwd_block;
        snprintf(out_name, 23, "%s", dst);
        return 0;
    }

    size_t plen = (size_t)(slash - dst);
    if (plen == 0) {
        snprintf(parentpath, sizeof(parentpath), "/");
    } else {
        if (plen >= sizeof(parentpath)) plen = sizeof(parentpath) - 1;
        memcpy(parentpath, dst, plen);
        parentpath[plen] = '\0';
    }

    if (vd_resolve_dir(cwd_block, parentpath, out_dir_block) != 0) return -1;
    snprintf(out_name, 23, "%s", slash + 1);
    return 0;
}

static int vd_create_or_overwrite_file(unsigned int dir_block, const char *name, unsigned int filesize, unsigned int new_firstblock)
{
    char nm[23];
    memset(nm, 0, sizeof(nm));
    snprintf(nm, sizeof(nm), "%s", name);

    struct metadata existing;
    unsigned int idx = 0;
    int found = (dir_find_child(dir_block, nm, 0, &existing, &idx) == 0);

    if (found) {
        if (existing.type != 'f') return -1;
        free_chain(existing.firstblock);
        existing.size = filesize;
        existing.firstblock = new_firstblock;
        return dir_write_entry(dir_block, idx, &existing);
    }

    unsigned int dsize = 0;
    if (dir_get_size(dir_block, &dsize) != 0) return -1;
    if (dir_ensure_capacity(dir_block, dsize + 1) != 0) return -1;

    struct metadata m;
    memset(&m, 0, sizeof(m));
    m.type = 'f';
    snprintf(m.name, sizeof(m.name), "%s", name);
    m.size = filesize;
    m.firstblock = new_firstblock;

    if (dir_write_entry(dir_block, dsize, &m) != 0) return -1;
    if (dir_set_size(dir_block, dsize + 1) != 0) return -1;

    dir_update_size_in_parent(dir_block);
    return 0;
}

int vd_cp(unsigned int cwd_block, const char *src, const char *dst)
{
    if (!src || !dst) return -1;

    int src_hd = (src[0] == '`');
    int dst_hd = (dst[0] == '`');

    const char *srcp = src_hd ? (src + 1) : src;
    const char *dstp = dst_hd ? (dst + 1) : dst;

    if (src_hd && dst_hd) return -1;

    /* HD -> VD */
    if (src_hd && !dst_hd) {
        FILE *in = fopen_hd_path(srcp, "rb");
        if (!in) {
            printf("*** Error: Unable to read input file %s\n", srcp);
            return -1;
        }

        if (fseek(in, 0, SEEK_END) != 0) {
            fclose(in);
            printf("*** Error: Unable to read input file %s\n", srcp);
            return -1;
        }
        long sz = ftell(in);
        if (sz < 0) {
            fclose(in);
            printf("*** Error: Unable to read input file %s\n", srcp);
            return -1;
        }
        rewind(in);

        unsigned int dirb = 0;
        char name[23];
        if (vd_parse_dest(cwd_block, dstp, &dirb, name) != 0) {
            fclose(in);
            return -1;
        }
        if (name[0] == '\0') {
            snprintf(name, sizeof(name), "%s", path_basename(srcp));
        }

        unsigned int fb = 0;
        if (vd_write_from_fd(in, (unsigned int)sz, &fb) != 0) {
            fclose(in);
            return -1;
        }
        fclose(in);

        if (vd_create_or_overwrite_file(dirb, name, (unsigned int)sz, fb) != 0) {
            free_chain(fb);
            return -1;
        }
        return 0;
    }

    /* VD -> HD */
    if (!src_hd && dst_hd) {
        struct metadata m;
        if (vd_resolve_any(cwd_block, srcp, &m, NULL, NULL) != 0 || m.type != 'f') {
            return -1;
        }

        FILE *out = fopen(dstp, "wb");
        if (!out) {
            return -1;
        }

        vd_read_to_fd(m.firstblock, m.size, out);
        fclose(out);
        return 0;
    }

    /* VD -> VD */
    struct metadata sm;
    if (vd_resolve_any(cwd_block, srcp, &sm, NULL, NULL) != 0 || sm.type != 'f') {
        return -1;
    }

    unsigned int dirb = 0;
    char name[23];
    if (vd_parse_dest(cwd_block, dstp, &dirb, name) != 0) {
        return -1;
    }
    if (name[0] == '\0') {
        /* copy under same name */
        snprintf(name, sizeof(name), "%s", path_basename(srcp));
    }

    unsigned int fb = 0;
    if (vd_write_from_vd(sm.firstblock, sm.size, &fb) != 0) {
        return -1;
    }

    if (vd_create_or_overwrite_file(dirb, name, sm.size, fb) != 0) {
        free_chain(fb);
        return -1;
    }

    return 0;
}

int vd_prn(unsigned int cwd_block, const char *path)
{
    struct metadata m;
    if (vd_resolve_any(cwd_block, path, &m, NULL, NULL) != 0) return -1;
    if (m.type != 'f') return -1;

    vd_read_to_fd(m.firstblock, m.size, stdout);
    return 0;
}
