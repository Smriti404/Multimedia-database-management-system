#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "diskutils.h"
static int starts_with(const char *s, const char *prefix)
{
    size_t n = strlen(prefix);
    return strncmp(s, prefix, n) == 0;
}

static void trim_newline(char *s)
{
    size_t n = strlen(s);
    if (n > 0 && s[n - 1] == '\n') s[n - 1] = '\0';
}

static unsigned int split_ws(char *line, char *argv[], unsigned int maxargv)
{
    unsigned int argc = 0;
    char *p = line;

    while (*p) {
        while (*p && (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n')) p++;
        if (!*p) break;
        if (argc >= maxargv) break;
        argv[argc++] = p;
        while (*p && *p != ' ' && *p != '\t' && *p != '\r' && *p != '\n') p++;
        if (*p) {
            *p = '\0';
            p++;
        }
    }

    return argc;
}

static void split_path_components(const char *path, char comps[][23], unsigned int *ncomps)
{
    *ncomps = 0;
    if (!path || !*path) return;

    size_t len = strlen(path);
    size_t i = 0;
    while (i < len) {
        while (i < len && path[i] == '/') i++;
        if (i >= len) break;
        size_t j = i;
        while (j < len && path[j] != '/') j++;
        size_t clen = j - i;
        if (clen >= 23) clen = 22;
        if (*ncomps < 256) {
            memset(comps[*ncomps], 0, 23);
            memcpy(comps[*ncomps], path + i, clen);
            comps[*ncomps][clen] = '\0';
            (*ncomps)++;
        }
        i = j;
    }
}

static void canon_path(const char *cwd, const char *arg, char *out, size_t outsz)
{
    char stack[256][23];
    unsigned int n = 0;

    if (arg && arg[0] == '/') {
        n = 0;
    } else {
        split_path_components(cwd, stack, &n);
    }

    if (arg && *arg) {
        char toks[256][23];
        unsigned int nt = 0;
        split_path_components(arg, toks, &nt);
        for (unsigned int i = 0; i < nt; i++) {
            if (strcmp(toks[i], ".") == 0 || strcmp(toks[i], "") == 0) continue;
            if (strcmp(toks[i], "..") == 0) {
                if (n > 0) n--;
                continue;
            }
            if (n < 256) {
                snprintf(stack[n], 23, "%.22s", toks[i]);
                n++;
            }
        }
    }

    if (n == 0) {
        if (outsz > 0) out[0] = '\0';
        return;
    }

    char buf[1024];
    buf[0] = '\0';
    for (unsigned int i = 0; i < n; i++) {
        strncat(buf, "/", sizeof(buf) - strlen(buf) - 1);
        strncat(buf, stack[i], sizeof(buf) - strlen(buf) - 1);
    }
    snprintf(out, outsz, "%s", buf);
}

int main(void)
{
    if (joindisk() != 0) {
        printf("*** Error: unable to join disk\n");
        return 1;
    }

    printf("+++ Number of blocks = %u\n", NBLOCKS);
    printf("+++ Number of free blocks = %u\n", NFREEBLOCKS);
    printf("+++ First block of the root directory = %u\n", RBN);

    unsigned int CBN = RBN;
    char CWD[1024];
    CWD[0] = '\0';

    char line[1024];
    char *argv[8];

    for (;;) {
        printf("[foosh] VD:%s> ", CWD);
        fflush(stdout);

        if (!fgets(line, sizeof(line), stdin)) break;
        trim_newline(line);
        if (line[0] == '\0') continue;

        unsigned int argc = split_ws(line, argv, 8);
        if (argc == 0) continue;

        const char *cmd = argv[0];

        if (strcmp(cmd, "exit") == 0 || strcmp(cmd, "quit") == 0) {
            break;
        }

        if (strcmp(cmd, "cd") == 0 || strcmp(cmd, "chdir") == 0) {
            const char *arg = (argc >= 2) ? argv[1] : "/";
            unsigned int newcbn = 0;
            if (vd_resolve_dir(CBN, arg, &newcbn) != 0) {
                printf("*** Error: unable to change to directory %s\n", arg);
                continue;
            }
            CBN = newcbn;
            canon_path(CWD, arg, CWD, sizeof(CWD));
            continue;
        }

        if (strcmp(cmd, "md") == 0 || strcmp(cmd, "mkdir") == 0) {
            if (argc < 2) {
                printf("*** Error: missing directory operand\n");
                continue;
            }
            if (vd_mkdir(CBN, argv[1]) != 0) {
                printf("*** Error: unable to create directory %s\n", argv[1]);
            }
            continue;
        }

        if (strcmp(cmd, "dir") == 0) {
            vd_dir(CBN);
            continue;
        }

        if (strcmp(cmd, "ls") == 0) {
            const char *arg = (argc >= 2) ? argv[1] : NULL;
            vd_ls(CBN, arg);
            continue;
        }

        if (strcmp(cmd, "cp") == 0 || strcmp(cmd, "copy") == 0) {
            if (argc < 3) {
                printf("*** Error: missing file operand\n");
                continue;
            }

            /* Enforce the assignment's HD disambiguation rule: HD paths must be quoted with ` */
            if (argv[1][0] != '`' && (starts_with(argv[1], "/home/") || starts_with(argv[1], "~/") || argv[1][0] == '~')) {
                printf("*** Error: HD file names must start with `\n");
                continue;
            }
            if (argv[2][0] != '`' && (starts_with(argv[2], "/home/") || starts_with(argv[2], "~/") || argv[2][0] == '~')) {
                /* Destination looks like HD but isn't quoted */
                printf("*** Error: HD file names must start with `\n");
                continue;
            }

            int rc = vd_cp(CBN, argv[1], argv[2]);
            if (rc != 0) {
                /* For HD<->VD copies, diskutils already prints the specific error. */
                if (argv[1][0] != '`' && argv[2][0] != '`') {
                    printf("*** Error: copy failed\n");
                }
            }
            continue;
        }

        if (strcmp(cmd, "prn") == 0 || strcmp(cmd, "type") == 0) {
            if (argc < 2) {
                printf("*** Error: missing file operand\n");
                continue;
            }
            vd_prn(CBN, argv[1]);
            continue;
        }

        /* unknown command: ignore */
    }

    printf("+++ Number of free blocks = %u\n", vd_get_nfreeblocks());
    leavedisk();
    return 0;
}
