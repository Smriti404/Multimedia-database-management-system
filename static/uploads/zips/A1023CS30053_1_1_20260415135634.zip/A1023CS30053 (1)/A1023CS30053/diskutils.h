#ifndef DISKUTILS_H
#define DISKUTILS_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Global variables required by the assignment */
extern unsigned char *D;       /* A pointer to the shared-memory segment storing VD */
extern unsigned int NBLOCKS;   /* The number of blocks on VD */
extern unsigned int NFREEBLOCKS; /* The number of free blocks on VD */
extern unsigned int RBN;       /* The first-block number of the root directory */

struct metadata {
    char type;                 /* 'f' or 'd' */
    char name[23];             /* null-terminated; for dirs we store trailing '/' */
    unsigned int size;         /* bytes for files; #entries for dirs */
    unsigned int firstblock;   /* first block of file/dir */
};

int joindisk(void);
void leavedisk(void);

unsigned int vd_get_nfreeblocks(void);

unsigned int getfreeblock(void);
int freeblock(unsigned int b);

/* Filesystem operations used by foosh */
int vd_mkdir(unsigned int cwd_block, const char *path);
int vd_ls(unsigned int cwd_block, const char *path);
int vd_dir(unsigned int cwd_block);
int vd_prn(unsigned int cwd_block, const char *path);
int vd_cp(unsigned int cwd_block, const char *src, const char *dst);

/* Path helpers */
int vd_resolve_dir(unsigned int cwd_block, const char *path, unsigned int *out_dir_block);
int vd_resolve_any(unsigned int cwd_block, const char *path, struct metadata *out_meta, unsigned int *out_parent_dir_block, unsigned int *out_meta_index);

#ifdef __cplusplus
}
#endif

#endif
