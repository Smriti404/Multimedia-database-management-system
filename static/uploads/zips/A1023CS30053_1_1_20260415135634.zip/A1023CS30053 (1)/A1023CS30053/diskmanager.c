#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <unistd.h>

#include "diskutils.h"

#define BLOCKSIZE 1024u
#define NBLOCKS_DEFAULT 65536u
#define VD_SIZE_BYTES (NBLOCKS_DEFAULT * BLOCKSIZE)

#define BITMAP_START_BLOCK 1u
#define BITMAP_NBLOCKS 8u
#define FAT_START_BLOCK 9u
#define FAT_NBLOCKS 256u
#define ROOTDIR_BLOCK 265u
#define DATA_START_BLOCK 266u

static key_t get_vd_key(void)
{
    /* Reproducible key: a file in the current directory */
    const char *keyfile = "vdisk.key";
    struct stat st;
    if (stat(keyfile, &st) != 0) {
        FILE *fp = fopen(keyfile, "wb");
        if (fp) fclose(fp);
    }
    key_t k = ftok(keyfile, 'V');
    return k;
}

static void write_u32(unsigned char *base, size_t off, unsigned int v)
{
    memcpy(base + off, &v, 4);
}

static void bitmap_set(unsigned char *bitmap, unsigned int b)
{
    unsigned int byte = b / 8u;
    unsigned int bit = b % 8u;
    bitmap[byte] |= (unsigned char)(1u << bit);
}

static void init_rootdir(unsigned char *D)
{
    unsigned char *root = D + ROOTDIR_BLOCK * BLOCKSIZE;
    memset(root, 0, BLOCKSIZE);

    struct metadata dot;
    memset(&dot, 0, sizeof(dot));
    dot.type = 'd';
    snprintf(dot.name, sizeof(dot.name), "./");
    dot.size = 2;
    dot.firstblock = ROOTDIR_BLOCK;

    struct metadata dotdot;
    memset(&dotdot, 0, sizeof(dotdot));
    dotdot.type = 'd';
    snprintf(dotdot.name, sizeof(dotdot.name), "../");
    dotdot.size = 0;
    dotdot.firstblock = ROOTDIR_BLOCK;

    memcpy(root + 0 * sizeof(struct metadata), &dot, sizeof(struct metadata));
    memcpy(root + 1 * sizeof(struct metadata), &dotdot, sizeof(struct metadata));
}

static int create_disk(void)
{
    key_t key = get_vd_key();
    if (key == (key_t)-1) {
        perror("ftok");
        return 1;
    }

    int shmid = shmget(key, VD_SIZE_BYTES, IPC_CREAT | IPC_EXCL | 0666);
    if (shmid < 0) {
        fprintf(stderr, "*** Error: shmget failed: %s\n", strerror(errno));
        return 1;
    }

    unsigned char *Dloc = (unsigned char *)shmat(shmid, NULL, 0);
    if (Dloc == (void *)-1) {
        fprintf(stderr, "*** Error: shmat failed: %s\n", strerror(errno));
        shmctl(shmid, IPC_RMID, NULL);
        return 1;
    }

    memset(Dloc, 0, VD_SIZE_BYTES);

    /* Block 0: NBLOCKS, NFREEBLOCKS, RBN */
    unsigned int nblocks = NBLOCKS_DEFAULT;
    unsigned int nfree = NBLOCKS_DEFAULT - (ROOTDIR_BLOCK + 1u);
    unsigned int rbn = ROOTDIR_BLOCK;
    unsigned int join_counter = 0;

    write_u32(Dloc, 0, nblocks);
    write_u32(Dloc, 4, nfree);
    write_u32(Dloc, 8, rbn);
    write_u32(Dloc, 12, join_counter);

    /* Bitmap: mark blocks 0..ROOTDIR_BLOCK allocated */
    unsigned char *bitmap = Dloc + BITMAP_START_BLOCK * BLOCKSIZE;
    memset(bitmap, 0, BITMAP_NBLOCKS * BLOCKSIZE);
    for (unsigned int b = 0; b <= ROOTDIR_BLOCK; b++) {
        bitmap_set(bitmap, b);
    }

    /* FAT already zeroed by memset */

    /* Root directory */
    init_rootdir(Dloc);

    shmdt(Dloc);
    return 0;
}

static int remove_disk(void)
{
    key_t key = get_vd_key();
    if (key == (key_t)-1) {
        perror("ftok");
        return 1;
    }

    int shmid = shmget(key, 1, 0666);
    if (shmid < 0) {
        fprintf(stderr, "*** Error: shmget failed: %s\n", strerror(errno));
        return 1;
    }

    if (shmctl(shmid, IPC_RMID, NULL) < 0) {
        fprintf(stderr, "*** Error: shmctl(IPC_RMID) failed: %s\n", strerror(errno));
        return 1;
    }

    return 0;
}

int main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "Usage: %s create|remove\n", argv[0]);
        return 1;
    }

    if (strcmp(argv[1], "create") == 0) {
        return create_disk();
    }
    if (strcmp(argv[1], "remove") == 0) {
        return remove_disk();
    }

    fprintf(stderr, "Usage: %s create|remove\n", argv[0]);
    return 1;
}
